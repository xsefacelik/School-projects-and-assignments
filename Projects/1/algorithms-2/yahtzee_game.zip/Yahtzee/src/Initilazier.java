
public class Initilazier {

	public static void main(String[] args){
		Yahtzee yahtzee = new Yahtzee();
	}
	
}
