
public class Initilazier {

	public static void main(String[] args) {
		WheelOfFortune game = new WheelOfFortune();
		}
}
