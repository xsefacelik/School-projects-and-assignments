
public class Initilazier {

	public static void main(String[] args) throws InterruptedException {
		Solitaire solitaire = new Solitaire();
	}
}
