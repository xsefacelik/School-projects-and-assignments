public class GameTest {
    public static void main(String[] args) throws InterruptedException {
        Game game = new Game();
        game.run();
    }
}