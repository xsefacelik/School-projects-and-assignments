
public class SearchEngineStarter {

	public static void main(String[] args) {
		SearchEngine start = new SearchEngine();
	}
}
